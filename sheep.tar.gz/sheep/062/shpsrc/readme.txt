#### README.TXT

This directory contains the generic (system independent) files of the
Sheep source. The Sheep Lisp source is elsewhere.

CUM.dif         Cumulative difference listing.

change.txt      Change log.
todo.txt        Future plans for Sheep.
readme.txt      This file.
problems.txt    Known problems with Sheep and Sheep Lisp.
redclash.txt    Problems with name clashes etc. Reduce/Sheep.
TAGS            TAGS file for Emacs editor.

shcref.sl       Declarations for rcref to cross reference Sheep.
globs.sl        Some variables declarations to mace rcref happy.
ishptst.sl      Test Sheep by calculating Einstein tensor for Godel
                metric.


cord.shp        Defines Einstein tensor in coordinate frame.


isheep.sl       Load sheep files (ilam and tensor).
ishmac.sl       Load macros needed when compiling Sheep files.

shpint.sl       Intialize some constants.


ilam.sl         Load system independent part of basic algebra package.

lglobl.sl       Define nonlocal variables for basic algebra.
helpfn.sl       Various help routines.
rename.sed      sedf commands to rename old functions.
rename.sl       Define renamed functions.

ssimp.sl        ssimp, simp1, simpe
scoll.sl        Simplify sum and product.
bigger.sl       Canonical ordering used by scoll.sl.
simpex.sl       simpi (simplify input) and simplify x^y, log x etc.
prifac.sl       Factorize number.
laritr.sl       Rational arithmetic.
(larith.sl)     Rational complex arithmetic (not used).
simpbl.sl       Construct addition, multiplication etc.
texpd.sl        Distributive law.

foin.sl         Formula input.

ddiff.sl        Differentiation.
funs.sl         Declare variables and functional dependence.

on.sl           On and off for switches.

prt.sl          Formula output, prt(x) = prtl(valu(x))
valu.sl         valu
prtl.sl         prtl

shpmcf.sl       Sheep macros.

shpmc.sl        Macros for compiler (same as shpmfn).
shpmfn.sl       Fexprs for interpreter (same as shpmc).

subl1.sl        Substitutions.

xtps.sl         Power series (Not yet implemented).


tensor.sl       Load tensor manipulation part of Sheep.

tglobl.sl       Define nonlocal variables for tensor part.

deften.sl       User interface to define new tensor objects.
xrank.sl        First processing of tensor type declaration.
dtenar.sl       Second processing of tensor type declaration.

ixtype.sl       Define index type (not in use).

geten.sl        Get tensor component.
karlim.sl       Transform between tensor and vector index.

tnpars.sl       User interface for tenval functions.
tenval.sl       Tenval functions.

sdet.sl         Compute determinant.

sumbou.sl       Support for tcomp.

Directories:
culisp          Cambridge Lisp specific code.
franz           Franz Lisp specific code.
psl             PSL (Portable Standard Lisp) specific code.
try             Experimental code.
bak             Contains links to last version for which CUM.dif
                is done.

#### README.TXT end
