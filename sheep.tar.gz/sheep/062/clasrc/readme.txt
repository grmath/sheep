This directory contains the source code for modules of Classi. Minor
machine dependent parts are kept in subdirectories to this directory.

readme.txt      This file
todo.txt        Things (improvements) to do.

bak             Directory for previous backup version.
culisp          Directory for Cambridge University Lisp specific code.
ctest           Directory for Culisp timing tests.
franz           Directory for Franz Lisp specific code.
ftest           Directory for Franz timing tests.
psl             Directory for Portable Standard Lisp specific code.
ptest           Directory for PSL timing tests.

autbia.shp      Automorphisms of Bianchi groups.
auto.shp        Obsolete.
chkcmp.shp      To check the number of components of n-th derivatives.
clabas.shp      Basic database part common for different parts of
                Classi.
claend.shp      Machine independent part of commands to make Classi
                image.
clamod.shp      Classi modules. Files to compile when making Classi.
classi.ini      Init file to be read when Classi is started.
classi.shp      Classification program top level.
clasum.shp      Produce one-line summary of classification.
clcref.shp      Some information to rcref.
constf.shp      Program to find nonrotating reference frame.
                Experimental.
clmod1.shp      A stripped down version of clamod for small computers.
clmod2.shp      Classi modules often loaded into Sheep.
clside.shp      Classi side modules that should load upon request.
cotraf.shp      Perform a coordinate transformation.
curvef.shp      Check if a curve is a geodesic.
d2rief.shp      Calculate 2nd covariant derivative of the Riemannian.
d3rief.shp      Calculate 3nd covariant derivative of the Riemannian.
demotn.shp      To perform demonstrations of classifications etc.
diainp.shp      To allow input in simple form for diagonal metrics.
dianul.shp      Obsolete.
diffrm.shp      Defines differentiation with respect to frame direction.
driec.shp       Coordinate components of covariant derivative of
                Riemannian.
drief.shp       Covariant derivative of Riemannian, Ricci tensor etc.
drsclf.shp      Covariant derivatives of curvature scalar.
drsqts.shp      Test of different algorithms to calculate RIESQ, DRIESQ
                etc.
dsgam.shp       Spinor covariant derivatives of spin coefficients.
dy2alt.shp      Dyad transformation for alternative standard form for
                Petrov type II.
dygen1.shp      Dyad transformation generator for Petrov type I.
dygen2.shp      Dyad transformation generator for Petrov type II.
dygen3.shp      Dyad transformation generator for Petrov type III.
dygend.shp      Dyad transformation generator for Petrov type D.
dygenn.shp      Dyad transformation generator for Petrov type N.
dytaut.shp      Automatic dyad transformation (for some cases).
dytrsp.shp      Dyad transformation for spinor dyads (null tetrads).
dytst.shp       Test of dytaut.shp.
dytsym.shp      Dyad transformation of symmetrised spinors.
eindvf.shp      Divergence of Einstein tensor.
einsqf.shp      Square of Einstein tensor.
einuuc.shp      Einstein tensor, contravariant coordinate components.
einuuf.shp      Einstein tensor, contravariant components.
eldyn3.shp      Electrodynamics in 3 dimensions.
eldync.shp      Electrodynamics in coordinate components.
eldynf.shp      Electrodynamical quantities, Einstein-Maxwells
                equations.
embed1.shp      Examination of geometries of embedding class 1.
embed2.shp      Examination of geometries of embedding class 2.
equ7sp.shp      Equivalence problem spinors up to 7-th derivative.
equspi.shp      Equivalence problem spinors up to 3rd derivative.
excurv.shp      Exterior curvature.
force3.shp      3-dim elasticity problem tensors.
frame.shp       For calculations in moving frame. Very important.
frmcrd.shp      Coordinate components from frame components.
frmdef.shp      Definitions to handle different frames.
funary.shp      Creates funtst arrays for current dimension.
funmac.shp      Macros creating funtst arrays for current dimension.
funts2.shp      Funtst arrays for the 2-dim case.
funts4.shp      Funtst arrays for the 4-dim case.
funtst.shp      Classification of functionally independent functions.
getnam.shp      To get metric file name from TITLE.
gframe.shp      General (non-constant) moving frame.
glims.shp       Limits, used e.g. to see that an expression is positive.
group.shp       Isometry group classification.
group3.shp      Addition to group.shp for 3-dim case.
hamil.shp       Hamiltonian formalism.
harris.shp      Common for all Harrison metrics.
hlpfns.shp      The basic module of functions for CLASSI.
hlpmac.shp      The basic module of macros used in CLASSI and at
                compile time.
hodgki.shp      Obsolete. Use embed1 and embed2.
iclass.shp      A simpler version of classi with better overview.
inewpn.shp      Internal version of newpen. Load rather newpen.
interi.shp      Moment of interia in mechanics (3-dim).
intfns.shp      Definition of numerical routines for trigonometric
                functions.
invrdf.shp      Invariants of covariant derivative of Riemannian.
invrf.shp       Invariants formed by the Riemannian.
invtrg.shp      Inverse trigonometric functions.
iric.shp        Input of Ricci tensor in input tetrad.
isotst.shp      Classification of isotropy group.
izud.shp        Input of frame metrics, allowing for transformations.
jacid.shp       Jacobi identities.
jefsfn.shp      J.E.F. Skea's functions.
killnc.shp      Killing vectors in coordinate components.
killnf.shp      Killing vectors.
kinner.shp      Common for all Kinnersley metrics.
laplf.shp       Laplace operator in 3-dim space.
matter.shp      Matter properties.
newfrm.shp      Riemannian tensor etc. in new frame.
newpen.shp      Newman-Penrose style calculations.
npeqns.shp      Newman-Penrose equations.
nuddnu.shp      Input as contravariant null directions.
nudnul.shp      Input as null directions.
ocontr.shp      Old versions of contraction functions etc.
perflu.shp      Perfect fluids test.
plast3.shp      Plasticity program, 3-dim.
plbnnl.shp      Plebanski classification. Obsolete.
pleban.shp      Plebanski classification.
poten3.shp      Potentials, 3-dim.
proots.shp      Obtains the roots of the Petrov quartic equation.
psiphi.shp      Defines the Riemannian spinors.
ptrvlr.shp      Petrov classification for Lorentz tetrad. Seldom used.
ptrvsp.shp      Petrov classification using spinors.
quadee.shp      The Einstein equations with a general quadratic
                Lagrangian.
quaten.shp      Some tensors needed for quadee.shp.
rainic.shp      The Rainich conditions for Electrovacuum.
reynol.shp      Fluid dynamics, 3-dim.
riedtf.shp      Determinant of Riemannian (regarded as a 6*6 matrix).
rieuc.shp       Coordinate components of Riemannian with first index
                raised.
rieuf.shp       Riemannian with first index raised.
roots1.shp      Obtains roots of quartic equation for Petrov type I.
roots2.shp      Obtains roots of quartic equation for Petrov type II.
roots3.shp      Obtains roots of quartic equation for Petrov type III.
rootsd.shp      Obtains roots of quartic equation for Petrov type D.
rootsn.shp      Obtains roots of quartic equation for Petrov type N.
rootst.shp      Test of proots.
rsimp.shp       Simplification of SHEEP expressions with REDUCE.
segre.shp       Segre classification.
shppow.shp      Factorisation of simpe factors for SHEEP-expressions.
solvtn.shp      Partial solver for simple differential equations.
spbian.shp      Bianchi identities in spinor form.
spcurv.shp      Spinor version of curvature tensor.
spinor.shp      Basic module for to handle spinors.
spitst.shp      Experimental module to study some spinor formulas.
symspi.shp      Basic module for handling of symmetrised spinors.
upbndf.shp      Plasticity calculations (for metal deformation), 3-dim.
weyl3f.shp      (2+1)-dim tensor corresponding to the Weyl tensor.
weyltc.shp      Coordinate components of the Weyl tensor.
weyltf.shp      The Weyl tensor.
xcord.shp       Alternative version of coordinate module cord.shp.

Files claini.shp, classr.shp, fout.shp and ricdia.shp have been
removed in version 56.
