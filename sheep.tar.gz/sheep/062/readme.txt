#### README.TXT

This is the top directory for Sheep, Classi and Stensor sources and
executables on the Orion. Documentation is in a separate directory.

The files in this directory are:

makefile        Makes all or parts of the system. See also makefiles
                in subdirectories like slsrc/culisp.

A few scripts that help in maintaining the system:
catcherr        Runs culisp returning 0 if all is ok.
chkfluid        Check log files for undefined fluids and errors.
dodiff          Runs diff on directories, but ignores certain files.
linklog         Links new versions of log directories.
vmake           Runs make with appropriate directories, output to file.
ivmake          Runs make with output into log file.
makeall         Makes all.

System initialisation files for:
sslisp.ini      Sheep Lisp.
sslc.ini        Sheep Lisp compiler (Only for separate compilers).
ssheep.ini      Sheep
sclassi.ini     Classi
sstensor.ini    Stensor

Directories:

Executables:
slisp
sheep
classi
stensor

Libraries:
slbin           Sheep Lisp binary directory.
shpbin          Sheep and Classi binary directory.
stslib          Stensor

Sources:
slsrc           Sheep Lisp
shpsrc          Sheep
clasrc          Classi
stssrc          Stensor
rcrsrc          Rcref (binary in slbin if any)

Others:
metrics         Metric files.
shpout          Output from running metric files.
diff            Differences between versions of sources.
spell           Spell check (sources).
splout          Output from spell check.
log             Log files from vmake.

#### README.TXT end
