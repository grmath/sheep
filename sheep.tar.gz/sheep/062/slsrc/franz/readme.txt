### README.TXT

This is a description of the source files that are used to generate
Sheep Lisp and a Sheep Lisp compiler SLC on top of Franz Lisp and
Liszt.

There are MAKEFILEs in two versions, one for Unix and one for Eunice.
They only differ in that the executable files have extension EXE under
VMS. In the following upper case names are used for files. Under UNIX
they will actually be lower case.
MAKEFILE.VMS
MAKEFILE.

Files that might be needed to change:
SLCMAKE.L and SLMAKE.L have some directory-specifications that you
might want to change. SYSTYPE.SL specifies what site you are at, so you 
probably want to change that.

1. SLC
SLC is made by patching Liszt. This is done by starting Liszt, loading
in PTLSZT.O and saving the result as SLC.
First compile CMACROS.L into CMACROS.O.
CMACROS.L.
Then compile PTLSZT.L into PTLSZT.O. To do this we need CMACROS.O and
CHEAD.L. Furthermore we use /usr/lib/lisp/syscall.o or .l
PTLSZT.L
Finally start Liszt and load in
SLCMAKE.L
this will make an executable file SLC or SLC.EXE.
SLC is completely compatible with Liszt i.e. it can replace Liszt.
The only difference from Liszt is that it can also compile Sheep
Lisp code.

2. SLMACS.O
To compile Sheep Lisp a set of macros etc. SLMACS.O is needed.
As part of the code for SLMACS is written in Sheep Lisp, a
bootstrapping process is needed. For this reason we first compile
SLMAC1.L into SLMAC1.O.
This uses sources
SLMAC1.L        Includes INCLUDE.L and SLMAC.L.
INCLDE.L        Temporary definition of INCLUDE.
SLMAC.L         Macros. Includes SLFUNS.L.
SLFUNS.L        Also in interpreter.

From now on SLC must be used instead of Liszt to compile.
Now compile SLMACS.L into SLMACS.O.
When you do this SLMAC.L will be recompiled first, then SLMAC1.O
will be loaded and thereafter EXFCOM.SL, PRINTF.SL and LOADF.SL
will be compiled.
Sources
SLMACS.L        Includes SLMAC.L and EXFCOM.SL.
SLMAC.L         See above.
SLFUNS.L        See above.
EXFCOM.SL       Extensions to the compiler. Includes
                (in the following order) EXFFN1.SL,
                EXCOM.SL, EXFFN2.SL, PRINTF.SL and
                LOADF.SL 
EXFFN1.SL       Extension to compiler and interpreter.
                Includes EXFN1.SL.
EXFN1.SL        System independent extensions to
                compiler and interpreter.
EXCOM.SL        System independent compiler extension.
EXFFN2.SL       Extension to compiler and interpreter.
                Includes EXFN2.SL, SYSTYP.SL and
                SLINI.SL.
EXFN2.SL        System independent extensions to
                compiler and interpreter.
SYSTYP.SL       Defines which system you have. You
                should change this appropriately.
SLINI.SL        Top level for interpreter.
PRINTF.SL       Define PRINTF a' la PSL.
LOADF.SL        Franz Lisp specific file handling.
                Includes LOAD.SL.
LOAD.SL         System independent module loading functions.

3. SLISP
Compile the files needed for the interpreter. Make SLISP.O, EXFINT.O,
PRINTF.O and LOADF.O.

Source for SLISP.O
SLISP.L         Interpreter version of SLMAC.L.
SLFUNS.L        See above.

Source for EXFINT.O
EXFINT.SL       Interpreter version of EXFCOM.SL.
                Includes EXFFN1.SL, EXFFN2.SL and
                EXINT.SL
EXFFN1.SL       See above.
EXFN1.SL        See above.
EXFFN2.SL       See above.
EXFN2.SL        See above.
SYSTYP.SL       See above.
SLINI.SL        See above.
EXINT.SL        Interpreter version of EXCOM.SL.

Source for PRINTF.O
PRINTF.SL       See above.

Source for LOADF.O
LOADF.SL        See above.
LOAD.SL         See above.

From the compiled files we build SLISP. This is done by starting
Franz Lisp and loading
SLMAKE.L
which will load the compiled files and save the result as NSLISP.
After you have checked that this is correct, rename it to SLISP.

### README.TXT end
