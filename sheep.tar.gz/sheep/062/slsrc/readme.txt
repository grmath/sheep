#### README.TXT

This directory contains the generic (system independent) files of the
Sheep Lisp source. The generic version is written as an extension of
Standard Lisp, but can be tailored for other Lisp systems (se
subdirectories). The Sheep source is elsewhere.

CUM.dif         Cumulative difference listing.

change.txt      Change log.
readme.txt      This file.
problems.txt    Known problems with Sheep Lisp.
TAGS            TAGS file for Emacs editor.

exfun.lis       List of functions etc. in Sheep Lisp.

const.l         Franz file that has to be one level above franz.

islisp.sl       Load Sheep Lisp files.
islmac.sl       Load macros needed when compiling Sheep files.

exfn1.sl        Basic code for function definition etc.
excom.sl        Compiler version of exint.
exint.sl        Interpreter version of excom.
exfn2.sl        More code.
slini.sl        Initialisation and top level.
load.sl         i/o routines, module loading functions.
printf.sl       printf, xerror. formated printing a'la PSL.
newnam.sl       Renaming of functions.

Directories:
culisp          Cambridge lisp specific code.
franz           Franz lisp specific code.
psl             PSL (Portable Standard Lisp) specific code.
slbin           Sheep Lisp library.
bak             Contains links to last version for which CUM.dif
                is done.

#### README.TXT end
