SHEEP, CLASSI and STENSOR documentation:

classi.man      Manual for CLASSI - Classification programs for Geometries
                in General Relativity.
contr.hlp       A mainly outdated text on contraction functions.
cord.hlp        Help file for the coordinate base G.R. programs.
frame.hlp       Help file for basic moving frame (tetrad) G.R. programs
guide.man       Example guide for SHEEP (essintially a chapter from sheep1.man)
install.txt     To install SHEEP, CLASSI and STENSOR on an ORION.
manhed.txt
metric.hlp      Information on metric files and their construction. Old.
news052.hlp     Most recent updates of CLASSI.
sheep.let       Letter from M. MacCallum to Prof. Bel on SHEEP2.
sheep1.man      Manual for SHEEP1.
sheep2.man      Provisional manual for SHEEP2, the SHEEP1 manual corrected
                only.
sheep2.mem      A text pointing out some of the more important differences
                between SHEEP1 and SHEEP2.
shfuns.txt      A text on how to add new tensor formulas using the SH...-
                functions.
shpfun.lis      An uncommented list of functions in SHEEP2.

stensor.txi     Reference Manual for STENSOR (1988), in TexInfo source formate.
                This source can also produce 'info-files' to be read by 'info'
                in gnuemacs. It is the main source for the TeX phototypeset
                laserprinted version, which you should request hardcopies of.
          Note: stensor.txi includes several MORE files when TeX-processed for
                laserprintout; Eg chapter 11 includes .hlp-files that live
                in stsdoc (see below). Similarly for many files 'allxxx.lis'.
                If you want to search for a specific Error/Warning -message
                for instance,check the file stsdoc/allE/W.lis,not stensor.txi!

stsdoc          STENSOR documentation directory, pointed to by symbol stsdoc,
                ie you may from anywhere do eg:   more $stsdoc/unix.hlp

tenpro.hlp      Out of date list on tensor programs. See rather clasrc/Readme.


For more information on STENSOR see separate list in stsdoc/papers.*
(hardcopy par 11.9), and for CLASSI and SHEEP see also (incomplete list):

 1. I. Frick, "The Computer Algebra System SHEEP, what it can and
    cannot do in General Relativity." University of Stockholm
    Institute of Physics Report 77-14 (1977).

 2. A. Karlhede and J.E. Aman, "Progress Towards a Solution
    of the Equivalence Problem in General Relativity",
    Eurosam 1979, Lecture Notes in Computer Science, Vol. 72,
    Springer-Verlag (1979) 42.

 3. A. Karlhede and J.E. Aman, "Classifying geometries in
    General Relativity", Abstracts of contributed papers, 9th
    International Conference on General Relativity and
    Gravitation (1980) 104.

 4. J.E. Aman and A. Karlhede, "A Computer-Aided Complete
    Classification of Geometries in General Relativity. First
    Results". Phys. Lett. 80 A (1980) 229.

 5. R.A. d'Inverno and I. Frick, "Interacting with SHEEP",
    Gen. Rel. Grav. 14 (1982) 935.

 6. A. Karlhede and J.E. Aman, "Inequivalent Metrics with
    Equal Spin Coefficients". Gen. Rel. Grav. 14 (1982) 49.

 7. J.E. Aman and A. Karlhede, "An Algoritmic Classification
    of Geometries in General Relativity". Proceedings of the
    1981 ACM Symposium on Symbolic and Algebraic Computation 
    (Symsac '81) (1981).

 8. A. Karlhede and J.E. Aman, "A Classification of the
    Vacuum D Metrics", preprint (1981).
 
 9. A. Karlhede, U. Lindstr|m and J.E. Aman, "A Note on a
    Local Effect at the Schwarzschild Sphere". Gen. Rel. Grav.
    14 (1982) 569.

10. J.E. Aman "Symbolic Computer Calculations in General
    Relativity", Thesis (1982).

11. A. Karlhede and M.A.H. MacCallum, "On Determining the
    Isometry Group of a Riemannian Space", Gen. Rel. Grav.
    14 (1982) 673.

12. M.A.H. MacCallum in "Unified field theories of more than 4
    dimensions including exact solutions", (Proceedings of the
    8th International School of Cosmology and Gravitation, Centro
    E. Majorana, Erice, Sicily) ed. V. de Sabbata and
    E. Schmutzer, World Scientific Publishing Co., Singapore
    (1983), p 352

13. J.E. Aman, R.A. d'Inverno, G.C. Joly and M.A.H. MacCallum
    "Quartic equations and classification of the Riemann tensor in
    General Relativity" in Eurosam '84, ed. J. Fitch, Springer
    Lecture notes in Computer Science 174 (1984) 47.

14. I. Cohen, I. Frick and J.E. Aman, "Algebraic Computing in General
    Relativity"  (Invited talk at GR10) in "General Relativity
    and Gravitation" ed. Bertotti, Felice and Pascolini, D. Reidel
    publishing comp. (1984) 139.

15. J.E. Aman, "Computer-Aided Classification of Geometries in
    General Relativity; Example: The Petrov type D vacuum metrics"
    in "Classical General Relativity" ed. Bonnor, Islam and
    MacCallum, Cambridge University Press (1984) 1.

16. M.A.H. MacCallum, "Algebraic computing in General Relativity"
    in "Classical General Relativity" ed. Bonnor, Islam and
    MacCallum, Cambridge University Press (1984) 145.

17. J.E. Aman, R.A. d'Inverno, G.C. Joly and M.A.H. MacCallum
    "Progress on the Equivalence problem", in Eurocal '85,
    ed. B. Caviness, Springer Lecture notes in Computer
    Science 204 (1985) 89.

18. A. Karlhede, "Classification of Euclidean metrics", Class.
    Quantum Grav. 3 (1986) L1.

19. J.E. Aman and M.A.H. MacCallum, "Algebraically Independent
    n-th Derivatives of th Riemannian Curvature Spinor in a
    General Space-Time", Class. Quant. Grav. 3 (1986) 1133.

20. M.A.H. MacCallum, J.E. Aman, "Algebraically independent
    n-th derivatives of the Riemannian curvature spinor",
    Proceedings of 11th International Conference on General
    Relativity and Gravitation (1986) 59.

21. M.A.H. MacCallum, J.E.F. Skea, R.A. d'Inverno, J.E. Aman
    "Progress on the equivalece problem", Proceedings of 11th
    International Conference on General Relativity and
    Gravitation (1986) 60.

22. M.A.H. MacCallum, R.A. d'Inverno, G.C. Joly, J.E. Aman
    "Quartics and computer-aided classification of the
    Riemannian tensor in General Relativity", Proceedings of
    11th International Conference on General Relativity and
    Gravitation (1986) 61.

23. J.E. Aman, R.A. d'Inverno, G.C. Joly and M.A.H. MacCallum
    "Quartic equations and algorithms for Riemann tensor
    classification", paper in preparation (1987).

24. G.C. Joly, M.A.H. MacCallum "Computer-Aided Classification
    of the Ricci tensor in General Relativity", In preparation.
